"""
This is the base class of realtime subsciber. subscriber_service and API is drived from this base class.
BCTWSConnection implements realtime_subscriber stub in secure and insecure mode. 
By default, the secure mode( over the ssl ) is enabled. 
"""

import requests
from realtime_subscriber import realtime_subscriber_pb2_grpc
from realtime_subscriber import realtime_subscriber_pb2
import grpc
import time
import multiprocessing
import enum
from realtime_subscriber import header_manipulator_client_interceptor
import logging
import atexit
from logging.handlers import TimedRotatingFileHandler
from logging import Formatter
import signal



class SubAuth(grpc.AuthMetadataPlugin):
    def __init__(self, udid, key):
        self._udid=udid
        self._key = key

        super().__init__()

    def __call__(self, context, callback):
        # callback((('bct-udid', self._udid),('rpc-auth-header-subscriber-user', self._key)), None)
        callback((('bct-udid', self._udid),('token', self._key),('type', '2')), None)




class BCTWSConnection:
    """
    This is the connection class. It implements connection to the server using realtime_subscriber stub. 
    This class 
    """

    def cleanUp(self):
        self.logger.info("cleaning background processes")
        self.p.terminate()
    class subscriptionOption(enum.Enum):
        FRAME=0
        LOOP_CHANGE=1
        PHASE_CHANGE=2

    def __init__(self, UDID, token, serverAddress=None,beaconAddress="https://realtime.us.beacon.1.api.bluecity.ai/",subscriptions=(subscriptionOption.FRAME,), cacheSize=400,singleton=False):

        self.UDID = UDID.lower()
        self.token = token
        self.serverAdd = serverAddress
        self.beaconAddress= beaconAddress
        self.cacheSize = cacheSize


        self.pingPeriod=5

        self.isInitialized=False

        self.singleton = singleton

        if  not self.singleton : 
            self.isSubscribed_frame=False
            self.isSubscribed_occupancy=False
            self.isSubscribed_phase=False
            if BCTWSConnection.subscriptionOption.FRAME in subscriptions:
                self.frames = multiprocessing.Queue()
                self.isSubscribed_frame=True
                self.initialized_frame = False

            if BCTWSConnection.subscriptionOption.LOOP_CHANGE in subscriptions:
                self.occupancies = multiprocessing.Queue()
                self.isSubscribed_occupancy=True
                self.initialized_occupancy = False


            if BCTWSConnection.subscriptionOption.PHASE_CHANGE in subscriptions:
                self.phases = multiprocessing.Queue()
                self.isSubscribed_phase=True
                self.initialized_phase = False
        else:
            self.queue = multiprocessing.Queue(maxsize=self.cacheSize)


        self.createLogger()
    

        # multiprocessing.Process(target=self.connect_secure).start()   
        atexit.register(self.cleanUp)
        self.p = multiprocessing.Process(target=self.run,daemon=True)
        self.p.start()
    
    def createLogger(self):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)

        # Create handler
        handler = TimedRotatingFileHandler(filename='realtime_subscriber.log', when='midnight', interval=1, backupCount=3, encoding='utf-8', delay=False)
        formatter = Formatter(fmt='%(asctime)s - %(levelname)s:\n%(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)

    def __pushToQueue(self,obj,queue):
        if queue.qsize() >= self.cacheSize:
            try:
                queue.get_nowait()
            except:
                self.logger.warning("was not able to reduce the size of fulled queue")
            
        try:
            queue.put_nowait(obj)
        except:
            self.logger.warning("was not able to put item in the queue")

    def restart(self,requestInitial=True):
        # TODO: Impelemnet restart mechanisim
        pass

    def __subscribe(self,stub):

            
        response=stub.subscribe(realtime_subscriber_pb2.SubscriptionRequest(initial = not self.isInitialized))
        item:realtime_subscriber_pb2.HyperParameter
        def cancelSubscription(signum, stack_frame):
            print("=========================================================================================")
            response.cancel()
            quit(0)

        signal.signal(signal.SIGINT,cancelSubscription)
        for item in response:
            self.isInitialized = True
            if self.singleton:
                if item.timestamp.strip()!="":
                    self.__pushToQueue(item,self.queue)
            else:
                if item.timestamp.strip()!="":
                    #TODO: check the subscription of users
                    if self.isSubscribed_frame and len(item.frame.objects) >0 :
                        item.frame.timestamp = item.timestamp
                        self.__pushToQueue(item.frame,self.frames)

                    if self.isSubscribed_phase and len(item.phaseChange.phases) >0:
                        item.phaseChange.timestamp = item.timestamp
                        self.__pushToQueue(item.phaseChange,self.phases)

                    if self.isSubscribed_occupancy and len(item.occupancyChange.occupancies) >0:
                        #occupancyChange doesn't have timestamp attribute 
                        # item.occupancyChange.timestamp = item.timestamp
                        self.__pushToQueue(item.occupancyChange,self.occupancies)

    def ping(self,stub):
        while True:
            time.sleep(self.pingPeriod)
            stub.ping(realtime_subscriber_pb2.Empty())

    def run (self):
        self.connect_secure()
        # self.connect_insecure()
        
    def getCredentials_beacon(self):
        self.crt = ""
        while self.serverAdd is None:
            try:
                res = requests.post(self.beaconAddress+"route",json={"UDID":self.UDID,"type":"2","token":self.token})
                if res.status_code ==200:
                    res = res.json()
                    self.serverAdd= res["address"]
                    self.crt =  res["key"].encode()
                    # _credentials.ROOT_CERTIFICATE = res["key"]
                    break
                else:
                    raise Exception()
            except Exception as ex:
                self.logger.error("Beacon is unreachable. Error {}".format(str(ex)))
                time.sleep(5)

    def connect_secure(self):

        while True:
            try:
                self.getCredentials_beacon()
                self.logger.info("connecting to the server {}".format(self.serverAdd))
                call_credentials = grpc.metadata_call_credentials(SubAuth(self.UDID,self.token),"subAuth")
                channel_credential = grpc.ssl_channel_credentials(self.crt)
                composite_credentials= grpc.composite_channel_credentials(channel_credential,call_credentials)
                with grpc.secure_channel('{}'.format(self.serverAdd), composite_credentials) as channel:
                    stub = realtime_subscriber_pb2_grpc.SubscriberStub(channel)
                    self.__subscribe(stub)
            except Exception as ex:
                self.serverAdd=None
                self.logger.critical(str(ex))
                time.sleep(10)    
    
    def connect_insecure(self):


        while True:
            try:
                self.logger.info("connecting to the server")
                with grpc.insecure_channel(self.serverAdd) as channel:
                    header_adder_interceptor = header_manipulator_client_interceptor.header_adder_interceptor(['bct-udid','token','type'], [self.UDID,self.token,'2'])
                    intercept_channel = grpc.intercept_channel(channel,header_adder_interceptor)

                    stub = realtime_pb2_grpc.SubscriberStub(intercept_channel)

                    # threading.Thread(target=self.ping,args=[stub]).start()
                    self.__subscribe(stub)
            except: 
                self.serverAdd=None
                self.logger.error("Connection to the server is lost. Retry in 5 seconds")
                time.sleep(10)           



    # ─── GET NOT SINGLETON ITEMS ────────────────────────────────────────────────────
    def get(self):
        frame_ = self.frames.get()
        strFormat=frame_.timestamp +','
        for obj in frame_.objects:
            strFormat+= obj.id +','
            strFormat+= str(obj.centerX) +','
            strFormat+= str(obj.centerY )+','
            strFormat+= str(obj.width )+','
            strFormat+= str(obj.length) +','
            strFormat+= str(obj.classType) +','
            strFormat+= '1,'
            strFormat+= str(obj.rotation) +','
            strFormat+= '1,'
            strFormat+= '1,'

        strFormat+= '<EOF>'

            
        return strFormat

    def get_frame(self):
        time.sleep(0.001)

        try:
            return self.frames.get()
        except:
            self.logger.critical("can not fetch frame data")

    def get_occupancy(self):
        time.sleep(0.001)
        try:
            return self.occupancies.get()
        except:
            self.logger.critical("can not fetch occupancy data")


    def get_phase(self):
        time.sleep(0.001)
        try:
            return self.phases.get()
        except:
            self.logger.critical("can not fetch phase data")

    
    # ────────────────────────────────────────────────────────────────────────────────


    # ─── GET SINGLETON ITEM ─────────────────────────────────────────────────────────

    def get_hyperparameter(self):
        time.sleep(0.001)
        return self.queue.get()
    # ────────────────────────────────────────────────────────────────────────────────

   

